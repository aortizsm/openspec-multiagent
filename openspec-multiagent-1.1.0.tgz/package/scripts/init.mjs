#!/usr/bin/env node
// init.mjs - One-command setup for the OpenSpec multi-agent workflow.
//
// Designed to run inside the USER'S PROJECT, not this repository:
//
//   npx openspec-multiagent init
//
// It does the whole job, in order, and is safe to re-run:
//   1. Runs `openspec init --tools opencode` when the project is not set up yet
//   2. Installs the agent definitions into the project (.opencode/agents)
//   3. Configures the Context7 MCP server
//   4. Prints a preflight summary
//
// It never runs `npm install` inside your project: OpenSpec is fetched through
// npx, so no node_modules is created. Use --global-agents to install the agents
// once for every project instead of the current one.
//
// Usage:
//   npx openspec-multiagent init              # set up the current directory
//   npx openspec-multiagent init --global-agents
//   npx openspec-multiagent init --context7 local
//   npx openspec-multiagent init --context7 none
//   npx openspec-multiagent init --skip-openspec-init
//   npx openspec-multiagent init --dry-run
//
// Context7 is asked about interactively when stdin is a TTY: whether to enable
// it at all, and whether to include an API key for higher rate limits. Passing
// any --context7/--skip-context7/--api-key flag skips the questions.

import { spawnSync } from "node:child_process";
import { existsSync } from "node:fs";
import { join } from "node:path";
import {
  MIN_OPENSPEC,
  SCRIPT_DIR,
  askChoice,
  askText,
  askYesNo,
  isInteractive,
  isOpenspecProject,
  parseArgs,
  resolveOpenspec,
  runOpenspec,
  which,
} from "./lib.mjs";

const { flags, values } = parseArgs(process.argv.slice(2));

if (flags.has("help")) {
  console.log(`openspec-multiagent init - Set up the multi-agent workflow in a project.

Options:
  --global-agents        Install the agents for every project instead of this one
  --context7 <mode>      How to wire Context7: 'remote' (default), 'local', or 'none'
  --api-key <KEY>        Include a Context7 API key for higher rate limits
  --no-api-key           Configure Context7 without an API key (the default)
  --skip-context7        Do not touch the Context7 MCP configuration
  --skip-openspec-init   Do not run 'openspec init' (assume it is done)
  --no-prompt            Never ask questions; use the defaults (for scripts/CI)
  --dry-run              Show what would happen without changing anything
  --help                 Show this help

Run it inside the project you want to use the workflow in.

When run in a terminal, it asks about Context7 (enable it, and whether to use an
API key). Passing --context7, --skip-context7 or --api-key answers for you.`);
  process.exit(0);
}

const projectDir = process.cwd();
const GLOBAL_AGENTS = flags.has("global-agents");
const SKIP_OPENSPEC_INIT = flags.has("skip-openspec-init");
const DRY_RUN = flags.has("dry-run");
const NO_PROMPT = flags.has("no-prompt") || !isInteractive();

// --- context7 options ----------------------------------------------------------
// Resolved up front (interactively when possible) so every later step, including
// --dry-run, knows the full plan.
const context7Flag = values.get("context7");
const apiKeyFlag = values.get("api-key");
const skipContext7Flag = flags.has("skip-context7");
const noApiKeyFlag = flags.has("no-api-key");

if (context7Flag && !["remote", "local", "none"].includes(context7Flag)) {
  console.error(`ERROR: --context7 must be 'remote', 'local' or 'none' (got '${context7Flag}')`);
  process.exit(2);
}

/** Set when the user answered the questions, to skip them on a re-run. */
const context7AnsweredByFlags =
  Boolean(context7Flag) || skipContext7Flag || Boolean(apiKeyFlag) || noApiKeyFlag;

let context7Enabled = true;
let context7Mode = context7Flag === "local" ? "local" : "remote";
let context7ApiKey = apiKeyFlag ?? "";

if (skipContext7Flag || context7Flag === "none") {
  context7Enabled = false;
}

const step = (n, msg) => console.log(`\n[${n}/4] ${msg}`);
const info = (msg) => console.log(`      ${msg}`);
const warn = (msg) => console.error(`      WARNING: ${msg}`);

console.log(`openspec-multiagent init`);
console.log(`  project: ${projectDir}`);
if (DRY_RUN) console.log(`  mode:    dry-run (nothing will be written)`);

// --- interactive Context7 questions --------------------------------------------
if (!context7AnsweredByFlags && !NO_PROMPT) {
  console.log("");
  console.log("Context7 gives agents up-to-date library documentation.");
  console.log("It works without an API key (lower rate limits) or with a free key.");
  console.log("");

  context7Enabled = await askYesNo("Enable Context7?", { defaultYes: true });

  if (context7Enabled) {
    context7Mode = await askChoice(
      "How should Context7 be connected?",
      [
        { value: "remote", label: "remote", hint: "hosted server, nothing to install" },
        { value: "local", label: "local", hint: "runs @upstash/context7-mcp on your machine" },
      ],
      { defaultIndex: 0 },
    );

    if (context7Mode === "remote") {
      const wantsKey = await askYesNo(
        "Use a Context7 API key for higher rate limits?",
        { defaultYes: false },
      );
      if (wantsKey) {
        console.log("      Get a free key at https://context7.com/dashboard");
        context7ApiKey = await askText("Paste the API key (or press Enter to skip):");
        if (!context7ApiKey) {
          console.log("      No key entered; continuing without one.");
        }
      }
    }
  }

  console.log("");
}

// --- 1. node -------------------------------------------------------------------
// A clear message beats a confusing module error on an unsupported runtime.
const [nMajor, nMinor, nPatch] = process.versions.node.split(".").map(Number);
const nodeOk =
  nMajor > 20 || (nMajor === 20 && (nMinor > 19 || (nMinor === 19 && nPatch >= 0)));
if (!nodeOk) {
  console.error(`\nERROR: Node.js ${process.versions.node} is too old (need >= 20.19.0).`);
  console.error("       Upgrade Node.js: https://nodejs.org");
  process.exit(1);
}

// --- 2. openspec init ----------------------------------------------------------
step(1, "OpenSpec project");

let openspec = null;
if (!SKIP_OPENSPEC_INIT) {
  openspec = resolveOpenspec();
  if (!openspec) {
    console.error("\nERROR: could not find or fetch the OpenSpec CLI.");
    console.error("       Install it with: npm i -g @fission-ai/openspec@latest");
    process.exit(1);
  }
  const [oMajor, oMinor] = openspec.version.split(".").map(Number);
  if (oMajor < MIN_OPENSPEC[0] || (oMajor === MIN_OPENSPEC[0] && oMinor < MIN_OPENSPEC[1])) {
    console.error(`\nERROR: OpenSpec ${openspec.version} is too old (need >= ${MIN_OPENSPEC.join(".")}).`);
    console.error("       Upgrade with: npm i -g @fission-ai/openspec@latest");
    process.exit(1);
  }
  info(`openspec ${openspec.version}${openspec.global ? " (global)" : " (via npx, nothing installed locally)"}`);

  if (isOpenspecProject(projectDir)) {
    info("project is already initialised; refreshing tool files");
  }

  if (DRY_RUN) {
    info("[dry-run] openspec init --tools opencode --no-animation");
  } else {
    // `openspec init` is idempotent and preserves existing files, so running it
    // on an existing project only refreshes the generated skills/commands.
    // captureOutput: under a TTY its spinner hangs (see runOpenspec).
    const result = runOpenspec(openspec, ["init", "--tools", "opencode", "--no-animation"], {
      cwd: projectDir,
      captureOutput: true,
    });
    if (result.status !== 0) {
      console.error("\nERROR: 'openspec init' failed. Fix the output above and re-run.");
      process.exit(1);
    }
    info("initialised .opencode/ (skills and commands)");
  }
} else {
  info("skipped (--skip-openspec-init)");
}

// --- 3. agents -----------------------------------------------------------------
step(2, "Agent definitions");
const agentsArgs = [join(SCRIPT_DIR, "install-agents.mjs")];
if (!GLOBAL_AGENTS) agentsArgs.push("--project");
if (DRY_RUN) agentsArgs.push("--dry-run");
{
  const result = spawnSync(process.execPath, agentsArgs, {
    stdio: "inherit",
    cwd: projectDir,
    shell: false,
  });
  if (result.status !== 0) {
    console.error("\nERROR: could not install the agent definitions.");
    process.exit(1);
  }
}

// --- 4. context7 ---------------------------------------------------------------
step(3, "Context7 MCP server");
if (!context7Enabled) {
  info(skipContext7Flag ? "skipped (--skip-context7)" : "skipped");
} else if (DRY_RUN) {
  const parts = [context7Mode === "local" ? "--local" : "--remote"];
  if (context7ApiKey) parts.push(`--api-key ${context7ApiKey}`);
  info(`[dry-run] install-context7.mjs ${parts.join(" ")}`);
} else {
  const c7Args = [join(SCRIPT_DIR, "install-context7.mjs")];
  if (context7Mode === "local") c7Args.push("--local");
  if (context7ApiKey) c7Args.push("--api-key", context7ApiKey);
  const result = spawnSync(process.execPath, c7Args, {
    stdio: "inherit",
    cwd: projectDir,
    shell: false,
  });
  if (result.status !== 0) {
    warn("could not configure Context7 automatically; see the message above.");
  }
}

// --- 5. summary ----------------------------------------------------------------
step(4, "Verification");
if (DRY_RUN) {
  info("[dry-run] check.mjs");
} else {
  const result = spawnSync(process.execPath, [join(SCRIPT_DIR, "check.mjs")], {
    stdio: "inherit",
    cwd: projectDir,
    shell: false,
  });
  if (result.status !== 0) {
    console.log("");
    console.log("Some checks failed. Fix them, then re-run: npx openspec-multiagent check");
  }
}

console.log("");
console.log("Done.");
console.log("");
console.log("Next:");
if (!GLOBAL_AGENTS) {
  console.log("  - The agents are installed in this project (.opencode/agents).");
  console.log("    OpenCode picks up project agents automatically when you start it here.");
} else {
  console.log("  - The agents are installed for every project (~/.config/opencode/agents).");
}
console.log("  - Start OpenCode in this directory and talk to @architect.");
console.log("  - Describe the change you want; @architect turns it into an OpenSpec spec.");

// Guard against the most common mistake: running this from the repository
// checkout instead of the user's project.
if (existsSync(join(projectDir, "opencode", "agents", "architect.md")) && !existsSync(join(projectDir, ".git"))) {
  console.log("");
  console.log("NOTE: this looks like the openspec-multiagent source tree. Run 'init' from");
  console.log("      your own project instead, so the workflow is installed where you work.");
}
